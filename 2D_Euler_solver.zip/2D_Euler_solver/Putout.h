#pragma once

extern void Putout();