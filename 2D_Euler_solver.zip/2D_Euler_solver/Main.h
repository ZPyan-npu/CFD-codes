#pragma once

#include <iostream>
#include <math.h>
#include <fstream>

#include "Variables_declear.h"