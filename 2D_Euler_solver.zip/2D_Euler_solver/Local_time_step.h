#pragma once

extern void Local_time_step();