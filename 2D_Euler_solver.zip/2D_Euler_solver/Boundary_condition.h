#pragma once

extern void Boundary_condition();