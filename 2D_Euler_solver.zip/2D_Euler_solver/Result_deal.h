#pragma once

extern void Result_deal();