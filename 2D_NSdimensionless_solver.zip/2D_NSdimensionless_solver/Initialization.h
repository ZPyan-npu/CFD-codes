#pragma once

extern void Initialization();