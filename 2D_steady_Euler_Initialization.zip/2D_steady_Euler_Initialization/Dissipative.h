#pragma once

extern void Dissipative();