#pragma once

#include "Main.h"

extern arma::mat Max4Matrices(arma::mat A, arma::mat B, arma::mat C, arma::mat D);
extern arma::mat Max2Matrices(arma::mat A, arma::mat B);