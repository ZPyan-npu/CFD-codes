#pragma once

#include <iostream>
#include <armadillo>
#include <math.h>
#include <fstream>
#include <string>
#include <sstream>

#include "VariablesDeclear.h"
