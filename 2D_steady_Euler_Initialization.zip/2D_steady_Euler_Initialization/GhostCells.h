#pragma once

extern void GhostCells();