#pragma once

extern void ReadMesh();