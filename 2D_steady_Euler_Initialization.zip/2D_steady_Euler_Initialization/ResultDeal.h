#pragma once

extern void ResultDeal();