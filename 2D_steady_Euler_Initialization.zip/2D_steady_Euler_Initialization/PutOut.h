#pragma once

extern void PutOut();