#pragma once

extern void DeleteArray();