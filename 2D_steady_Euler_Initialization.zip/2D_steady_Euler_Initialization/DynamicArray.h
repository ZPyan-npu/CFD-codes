#pragma once

extern void DynamicArray();