#pragma once

extern void LocalTimeStep();