#pragma once

extern void InitialValues();