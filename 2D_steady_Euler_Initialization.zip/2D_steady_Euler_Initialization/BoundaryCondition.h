#pragma once

extern void BoundaryCondition();