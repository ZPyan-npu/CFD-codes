#pragma once

extern void Diffusive();