#pragma once

extern void Residual();