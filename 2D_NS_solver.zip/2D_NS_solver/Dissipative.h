#pragma once

extern void Dissipative();
extern double Max(double a, double b, double c, double d);