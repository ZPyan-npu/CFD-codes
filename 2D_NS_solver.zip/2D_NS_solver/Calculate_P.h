#pragma once

extern void Calculate_P();