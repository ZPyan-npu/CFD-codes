#pragma once

extern void Primitive();