#pragma once

extern void Ghost_cells();