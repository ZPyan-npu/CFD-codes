#pragma once

extern void Min_time_step();